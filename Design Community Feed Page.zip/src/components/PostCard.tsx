import { useState } from 'react';
import { Heart, MessageCircle, MoreVertical, Calendar, CheckCircle, Send } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { Input } from './ui/input';
import { ImageWithFallback } from './figma/ImageWithFallback';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

interface Comment {
  id: string;
  author: string;
  text: string;
  date: string;
}

interface Post {
  id: string;
  title: string;
  date: string;
  author: string;
  verified: boolean;
  content: string;
  image: string | null;
  likes: number;
  comments: Comment[];
}

interface PostCardProps {
  post: Post;
}

export function PostCard({ post }: PostCardProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(post.likes);
  const [isCommentsOpen, setIsCommentsOpen] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [comments, setComments] = useState(post.comments);

  const handleLike = () => {
    if (isLiked) {
      setLikesCount(likesCount - 1);
      setIsLiked(false);
    } else {
      setLikesCount(likesCount + 1);
      setIsLiked(true);
    }
  };

  const handleAddComment = () => {
    if (commentText.trim()) {
      const newComment: Comment = {
        id: String(comments.length + 1),
        author: 'Anonymous',
        text: commentText,
        date: new Date().toISOString().split('T')[0]
      };
      setComments([...comments, newComment]);
      setCommentText('');
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  return (
    <div className="bg-white border border-[#e5e7eb] rounded-xl p-5 sm:p-6 hover:border-[#d1d5db] transition-colors">
      {/* Header */}
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex-1">
          <h3 className="text-[#111] mb-2">{post.title}</h3>
          <div className="flex items-center gap-2 text-[#666]">
            <Calendar className="w-4 h-4" />
            <span className="text-sm">{formatDate(post.date)}</span>
          </div>
        </div>
        {post.verified && (
          <Badge className="bg-[#eff6ff] text-[#0b5fff] border-[#0b5fff]/20 hover:bg-[#eff6ff] gap-1 px-2 py-1">
            <CheckCircle className="w-3 h-3" />
            Verified
          </Badge>
        )}
      </div>

      {/* Content */}
      <p className="text-[#333] mb-4">{post.content}</p>

      {/* Image */}
      {post.image && (
        <div className="mb-4 rounded-lg overflow-hidden">
          <ImageWithFallback
            src={post.image}
            alt={post.title}
            className="w-full h-auto object-cover"
          />
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center gap-4 pt-4 border-t border-[#e5e7eb]">
        <button
          onClick={handleLike}
          className="flex items-center gap-2 text-[#666] hover:text-[#0b5fff] transition-colors group"
        >
          <Heart 
            className={`w-5 h-5 transition-all ${
              isLiked ? 'fill-[#0b5fff] text-[#0b5fff]' : 'group-hover:scale-110'
            }`}
          />
          <span className="text-sm">{likesCount}</span>
        </button>

        <Collapsible open={isCommentsOpen} onOpenChange={setIsCommentsOpen}>
          <CollapsibleTrigger asChild>
            <button className="flex items-center gap-2 text-[#666] hover:text-[#0b5fff] transition-colors">
              <MessageCircle className="w-5 h-5" />
              <span className="text-sm">{comments.length}</span>
            </button>
          </CollapsibleTrigger>

          <CollapsibleContent className="mt-4 space-y-3">
            {/* Comments List */}
            {comments.length > 0 && (
              <div className="space-y-3 mb-3">
                {comments.map((comment) => (
                  <div key={comment.id} className="bg-[#f9fafb] rounded-lg p-3 border border-[#e5e7eb]">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm text-[#666]">{comment.author}</span>
                      <span className="text-xs text-[#999]">· {formatDate(comment.date)}</span>
                    </div>
                    <p className="text-sm text-[#333]">{comment.text}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Add Comment */}
            <div className="flex gap-2">
              <Input
                type="text"
                placeholder="Write a comment..."
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleAddComment();
                  }
                }}
                className="flex-1 border-[#e5e7eb] rounded-lg"
              />
              <Button
                onClick={handleAddComment}
                size="icon"
                className="bg-[#0b5fff] hover:bg-[#0949cc] text-white rounded-lg"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </CollapsibleContent>
        </Collapsible>

        <div className="ml-auto">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="text-[#666] hover:text-[#111] h-8 w-8">
                <MoreVertical className="w-5 h-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem className="cursor-pointer">Report post</DropdownMenuItem>
              <DropdownMenuItem className="cursor-pointer">Save post</DropdownMenuItem>
              <DropdownMenuItem className="cursor-pointer">Share post</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
}
