import { useState } from 'react';
import { NavigationBar } from './components/NavigationBar';
import { EventCard } from './components/EventCard';
import { FloatingActionButton } from './components/FloatingActionButton';
import { Calendar } from './components/ui/calendar';
import { Card } from './components/ui/card';

const mockEvents = [
  {
    id: '1',
    title: 'CS Department Career Fair',
    date: '2025-11-05',
    time: '10:00 AM - 4:00 PM',
    venue: 'Engineering Building, Hall A',
    participants: 127,
    userRSVP: true,
    description: 'Meet with top tech companies and explore internship and full-time opportunities. Bring your resume!',
    image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&q=80',
    likes: 89,
    comments: 12
  },
  {
    id: '2',
    title: 'Fall Semester Study Break - Free Coffee & Snacks',
    date: '2025-11-01',
    time: '2:00 PM - 5:00 PM',
    venue: 'Student Center, Main Lounge',
    participants: 245,
    userRSVP: true,
    description: 'Take a break from studying! Join us for free coffee, snacks, and board games.',
    image: 'https://images.unsplash.com/photo-1511578314322-379afb476865?w=800&q=80',
    likes: 156,
    comments: 23
  },
  {
    id: '3',
    title: 'Hackathon 2025: Build for Good',
    date: '2025-11-08',
    time: '9:00 AM - 9:00 PM',
    venue: 'Innovation Lab, Building 7',
    participants: 89,
    userRSVP: false,
    description: '12-hour hackathon focused on social impact projects. Form teams or join solo. Prizes for top 3 teams!',
    image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800&q=80',
    likes: 67,
    comments: 18
  },
  {
    id: '4',
    title: 'Wellness Wednesday: Yoga & Meditation',
    date: '2025-11-06',
    time: '5:30 PM - 6:30 PM',
    venue: 'Recreation Center, Studio B',
    participants: 34,
    userRSVP: false,
    description: 'De-stress with a guided yoga and meditation session. All skill levels welcome. Bring your own mat.',
    image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800&q=80',
    likes: 45,
    comments: 7
  },
  {
    id: '5',
    title: 'International Food Festival',
    date: '2025-11-10',
    time: '12:00 PM - 6:00 PM',
    venue: 'Campus Quad',
    participants: 312,
    userRSVP: true,
    description: 'Celebrate diversity with food from around the world! Student clubs will showcase their cultural cuisines.',
    image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800&q=80',
    likes: 234,
    comments: 45
  },
  {
    id: '6',
    title: 'Alumni Speaker Series: Entrepreneurship',
    date: '2025-11-03',
    time: '6:00 PM - 7:30 PM',
    venue: 'Business School, Auditorium 101',
    participants: 156,
    userRSVP: false,
    description: 'Hear from successful alumni entrepreneurs about their journey from campus to startup.',
    image: 'https://images.unsplash.com/photo-1475721027785-f74eccf877e2?w=800&q=80',
    likes: 92,
    comments: 15
  }
];

export default function EventsPage() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [events] = useState(mockEvents);

  return (
    <div className="min-h-screen bg-white">
      <NavigationBar activeTab="events" />
      
      {/* Main Content */}
      <main className="max-w-[1200px] mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-[#111] mb-1">CAMPUS EVENTS</h1>
          <p className="text-[#666]">Discover and join upcoming events</p>
        </div>

        {/* Layout: Calendar + Events */}
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Calendar Section */}
          <div className="lg:w-[320px] shrink-0">
            <Card className="p-4 border-[#e5e7eb] rounded-xl">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-lg"
              />
            </Card>
          </div>

          {/* Events List */}
          <div className="flex-1">
            <div className="space-y-4">
              {events.map((event) => (
                <EventCard key={event.id} event={event} />
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* Mobile Floating Action Button */}
      <FloatingActionButton />
    </div>
  );
}
