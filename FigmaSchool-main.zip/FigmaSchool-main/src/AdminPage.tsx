import { useState } from 'react';
import { NavigationBar } from './components/NavigationBar';
import { Card } from './components/ui/card';
import { Button } from './components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Badge } from './components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './components/ui/avatar';
import { 
  Users, 
  MessageSquare, 
  Calendar,
  ShoppingBag,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Mail,
  GraduationCap,
  BadgeCheck,
  TrendingUp,
  Clock
} from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './components/ui/table';

const adminStats = {
  totalUsers: 1247,
  pendingApprovals: 8,
  activePosts: 156,
  upcomingEvents: 12,
  activeListings: 43,
  reportedContent: 3
};

const pendingUsers = [
  {
    id: '1',
    name: 'Sarah Johnson',
    email: 'sarah.johnson@campus.edu',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&q=80',
    appliedDate: '2025-10-30',
    status: 'Pending',
    criteria: {
      campusEmail: true,
      studentId: true,
      enrollmentVerified: true,
      profileComplete: true
    },
    major: 'Business Administration',
    graduationYear: '2027',
    reason: 'New student transfer from State University'
  },
  {
    id: '2',
    name: 'Michael Chen',
    email: 'michael.chen@campus.edu',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80',
    appliedDate: '2025-10-30',
    status: 'Pending',
    criteria: {
      campusEmail: true,
      studentId: true,
      enrollmentVerified: false,
      profileComplete: true
    },
    major: 'Mechanical Engineering',
    graduationYear: '2026',
    reason: 'Current student - Fall 2025 enrollment'
  },
  {
    id: '3',
    name: 'Emily Rodriguez',
    email: 'emily.rodriguez@campus.edu',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&q=80',
    appliedDate: '2025-10-29',
    status: 'Pending',
    criteria: {
      campusEmail: true,
      studentId: true,
      enrollmentVerified: true,
      profileComplete: false
    },
    major: 'Psychology',
    graduationYear: '2025',
    reason: 'Alumni verification pending'
  },
  {
    id: '4',
    name: 'David Kim',
    email: 'david.kim@campus.edu',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&q=80',
    appliedDate: '2025-10-29',
    status: 'Pending',
    criteria: {
      campusEmail: true,
      studentId: true,
      enrollmentVerified: true,
      profileComplete: true
    },
    major: 'Computer Science',
    graduationYear: '2026',
    reason: 'New student - Spring 2026 enrollment'
  },
  {
    id: '5',
    name: 'Jessica Martinez',
    email: 'jessica.martinez@campus.edu',
    avatar: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=400&q=80',
    appliedDate: '2025-10-28',
    status: 'Pending',
    criteria: {
      campusEmail: true,
      studentId: false,
      enrollmentVerified: true,
      profileComplete: true
    },
    major: 'Marketing',
    graduationYear: '2027',
    reason: 'Current student - verification needed'
  }
];

const recentReports = [
  {
    id: '1',
    type: 'Post',
    title: 'Inappropriate language in community post',
    reportedBy: 'Anonymous',
    date: '2025-10-30',
    status: 'Under Review'
  },
  {
    id: '2',
    type: 'Marketplace',
    title: 'Suspected scam listing - iPhone 15 Pro',
    reportedBy: 'Anonymous',
    date: '2025-10-29',
    status: 'Under Review'
  },
  {
    id: '3',
    type: 'Post',
    title: 'Spam content',
    reportedBy: 'Anonymous',
    date: '2025-10-28',
    status: 'Resolved'
  }
];

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState('approvals');
  const [users, setUsers] = useState(pendingUsers);

  const handleApprove = (userId: string) => {
    setUsers(users.filter(user => user.id !== userId));
    // In a real app, this would make an API call
  };

  const handleReject = (userId: string) => {
    setUsers(users.filter(user => user.id !== userId));
    // In a real app, this would make an API call
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getCriteriaProgress = (criteria: any) => {
    const total = Object.keys(criteria).length;
    const completed = Object.values(criteria).filter(Boolean).length;
    return { completed, total, percentage: (completed / total) * 100 };
  };

  return (
    <div className="min-h-screen bg-white">
      <NavigationBar activeTab="admin" />
      
      {/* Main Content */}
      <main className="max-w-[1200px] mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-[#111] mb-1">ADMIN DASHBOARD</h1>
          <p className="text-[#666]">Manage users, content, and platform settings</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          <Card className="p-4 border-[#e5e7eb] rounded-xl">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-[#eff6ff] flex items-center justify-center">
                <Users className="w-5 h-5 text-[#0b5fff]" />
              </div>
            </div>
            <div className="text-[#111] mb-1">{adminStats.totalUsers}</div>
            <div className="text-xs text-[#666]">Total Users</div>
          </Card>

          <Card className="p-4 border-[#e5e7eb] rounded-xl">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-[#fef3c7] flex items-center justify-center">
                <Clock className="w-5 h-5 text-[#d97706]" />
              </div>
            </div>
            <div className="text-[#111] mb-1">{adminStats.pendingApprovals}</div>
            <div className="text-xs text-[#666]">Pending Approvals</div>
          </Card>

          <Card className="p-4 border-[#e5e7eb] rounded-xl">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-[#f0fdf4] flex items-center justify-center">
                <MessageSquare className="w-5 h-5 text-[#059669]" />
              </div>
            </div>
            <div className="text-[#111] mb-1">{adminStats.activePosts}</div>
            <div className="text-xs text-[#666]">Active Posts</div>
          </Card>

          <Card className="p-4 border-[#e5e7eb] rounded-xl">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-[#fef2f2] flex items-center justify-center">
                <Calendar className="w-5 h-5 text-[#dc2626]" />
              </div>
            </div>
            <div className="text-[#111] mb-1">{adminStats.upcomingEvents}</div>
            <div className="text-xs text-[#666]">Upcoming Events</div>
          </Card>

          <Card className="p-4 border-[#e5e7eb] rounded-xl">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-[#f5f3ff] flex items-center justify-center">
                <ShoppingBag className="w-5 h-5 text-[#7c3aed]" />
              </div>
            </div>
            <div className="text-[#111] mb-1">{adminStats.activeListings}</div>
            <div className="text-xs text-[#666]">Active Listings</div>
          </Card>

          <Card className="p-4 border-[#e5e7eb] rounded-xl">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-[#fef2f2] flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-[#dc2626]" />
              </div>
            </div>
            <div className="text-[#111] mb-1">{adminStats.reportedContent}</div>
            <div className="text-xs text-[#666]">Reports</div>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full sm:w-auto bg-white border border-[#e5e7eb] p-1 mb-6">
            <TabsTrigger 
              value="approvals" 
              className="data-[state=active]:bg-[#0b5fff] data-[state=active]:text-white px-4 py-2 rounded-lg gap-2"
            >
              <BadgeCheck className="w-4 h-4" />
              Pending Approvals ({users.length})
            </TabsTrigger>
            <TabsTrigger 
              value="reports" 
              className="data-[state=active]:bg-[#0b5fff] data-[state=active]:text-white px-4 py-2 rounded-lg gap-2"
            >
              <AlertTriangle className="w-4 h-4" />
              Reports ({recentReports.filter(r => r.status === 'Under Review').length})
            </TabsTrigger>
            <TabsTrigger 
              value="analytics" 
              className="data-[state=active]:bg-[#0b5fff] data-[state=active]:text-white px-4 py-2 rounded-lg gap-2"
            >
              <TrendingUp className="w-4 h-4" />
              Analytics
            </TabsTrigger>
          </TabsList>

          {/* Pending Approvals */}
          <TabsContent value="approvals">
            <div className="space-y-4">
              {users.map((user) => {
                const progress = getCriteriaProgress(user.criteria);
                const isFullyQualified = progress.percentage === 100;
                
                return (
                  <Card key={user.id} className="p-5 sm:p-6 border-[#e5e7eb] rounded-xl">
                    <div className="flex flex-col sm:flex-row gap-5">
                      {/* User Info */}
                      <div className="flex items-start gap-4 flex-1">
                        <Avatar className="w-16 h-16 border-2 border-white shadow-sm">
                          <AvatarImage src={user.avatar} alt={user.name} />
                          <AvatarFallback className="bg-[#0b5fff] text-white">
                            {user.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>

                        <div className="flex-1">
                          <h3 className="text-[#111] mb-1">{user.name}</h3>
                          <div className="flex flex-col gap-1 text-sm text-[#666] mb-3">
                            <div className="flex items-center gap-1.5">
                              <Mail className="w-4 h-4" />
                              <span>{user.email}</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <GraduationCap className="w-4 h-4" />
                              <span>{user.major} • Class of {user.graduationYear}</span>
                            </div>
                          </div>
                          
                          <div className="bg-[#f9fafb] rounded-lg p-3 mb-3 border border-[#e5e7eb]">
                            <div className="text-sm text-[#666] mb-1">Application Reason:</div>
                            <div className="text-sm text-[#111]">{user.reason}</div>
                          </div>

                          {/* Verification Criteria */}
                          <div className="space-y-2">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm text-[#666]">Verification Criteria</span>
                              <span className="text-sm text-[#111]">
                                {progress.completed}/{progress.total} completed
                              </span>
                            </div>
                            
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              <div className={`flex items-center gap-2 text-sm ${user.criteria.campusEmail ? 'text-[#059669]' : 'text-[#dc2626]'}`}>
                                {user.criteria.campusEmail ? (
                                  <CheckCircle className="w-4 h-4" />
                                ) : (
                                  <XCircle className="w-4 h-4" />
                                )}
                                <span>Campus Email Verified</span>
                              </div>
                              
                              <div className={`flex items-center gap-2 text-sm ${user.criteria.studentId ? 'text-[#059669]' : 'text-[#dc2626]'}`}>
                                {user.criteria.studentId ? (
                                  <CheckCircle className="w-4 h-4" />
                                ) : (
                                  <XCircle className="w-4 h-4" />
                                )}
                                <span>Student ID Provided</span>
                              </div>
                              
                              <div className={`flex items-center gap-2 text-sm ${user.criteria.enrollmentVerified ? 'text-[#059669]' : 'text-[#dc2626]'}`}>
                                {user.criteria.enrollmentVerified ? (
                                  <CheckCircle className="w-4 h-4" />
                                ) : (
                                  <XCircle className="w-4 h-4" />
                                )}
                                <span>Enrollment Verified</span>
                              </div>
                              
                              <div className={`flex items-center gap-2 text-sm ${user.criteria.profileComplete ? 'text-[#059669]' : 'text-[#dc2626]'}`}>
                                {user.criteria.profileComplete ? (
                                  <CheckCircle className="w-4 h-4" />
                                ) : (
                                  <XCircle className="w-4 h-4" />
                                )}
                                <span>Profile Complete</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex sm:flex-col gap-2 sm:w-[140px] shrink-0">
                        <Badge className="bg-[#fef3c7] text-[#d97706] border-[#d97706]/20 hover:bg-[#fef3c7] text-xs px-2 py-1 self-start mb-2">
                          Applied {formatDate(user.appliedDate)}
                        </Badge>
                        
                        {isFullyQualified && (
                          <Badge className="bg-[#ecfdf5] text-[#059669] border-[#059669]/20 hover:bg-[#ecfdf5] text-xs px-2 py-1 self-start mb-2">
                            Fully Qualified
                          </Badge>
                        )}
                        
                        <Button 
                          onClick={() => handleApprove(user.id)}
                          className="bg-[#059669] hover:bg-[#047857] text-white px-4 py-2 rounded-lg gap-2 w-full"
                        >
                          <CheckCircle className="w-4 h-4" />
                          Approve
                        </Button>
                        
                        <Button 
                          onClick={() => handleReject(user.id)}
                          className="bg-white border border-[#e5e7eb] text-[#dc2626] hover:bg-[#fef2f2] px-4 py-2 rounded-lg gap-2 w-full"
                        >
                          <XCircle className="w-4 h-4" />
                          Reject
                        </Button>
                      </div>
                    </div>
                  </Card>
                );
              })}

              {users.length === 0 && (
                <Card className="p-8 border-[#e5e7eb] rounded-xl">
                  <div className="text-center text-[#666]">
                    <CheckCircle className="w-12 h-12 mx-auto mb-3 text-[#059669]" />
                    <p>No pending approvals at this time</p>
                  </div>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Reports */}
          <TabsContent value="reports">
            <Card className="border-[#e5e7eb] rounded-xl overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="border-[#e5e7eb]">
                    <TableHead className="text-[#111]">Type</TableHead>
                    <TableHead className="text-[#111]">Description</TableHead>
                    <TableHead className="text-[#111]">Reported By</TableHead>
                    <TableHead className="text-[#111]">Date</TableHead>
                    <TableHead className="text-[#111]">Status</TableHead>
                    <TableHead className="text-[#111]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentReports.map((report) => (
                    <TableRow key={report.id} className="border-[#e5e7eb]">
                      <TableCell>
                        <Badge className="bg-[#f5f5f5] text-[#666] border-[#e5e7eb] hover:bg-[#f5f5f5]">
                          {report.type}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-[#111]">{report.title}</TableCell>
                      <TableCell className="text-[#666]">{report.reportedBy}</TableCell>
                      <TableCell className="text-[#666]">{formatDate(report.date)}</TableCell>
                      <TableCell>
                        <Badge className={
                          report.status === 'Under Review' 
                            ? 'bg-[#fef3c7] text-[#d97706] border-[#d97706]/20 hover:bg-[#fef3c7]'
                            : 'bg-[#ecfdf5] text-[#059669] border-[#059669]/20 hover:bg-[#ecfdf5]'
                        }>
                          {report.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button className="bg-white border border-[#e5e7eb] text-[#111] hover:bg-[#f9fafb] px-3 py-1 rounded-lg text-sm">
                          Review
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>

          {/* Analytics */}
          <TabsContent value="analytics">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="p-6 border-[#e5e7eb] rounded-xl">
                <h3 className="text-[#111] mb-4">User Growth</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[#666]">This Month</span>
                    <span className="text-[#111]">+87 users</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#666]">Last Month</span>
                    <span className="text-[#666]">+64 users</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-[#059669]">
                    <TrendingUp className="w-4 h-4" />
                    <span>35% increase</span>
                  </div>
                </div>
              </Card>

              <Card className="p-6 border-[#e5e7eb] rounded-xl">
                <h3 className="text-[#111] mb-4">Platform Activity</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[#666]">Daily Active Users</span>
                    <span className="text-[#111]">423</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#666]">Posts This Week</span>
                    <span className="text-[#111]">89</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#666]">Events Created</span>
                    <span className="text-[#111]">12</span>
                  </div>
                </div>
              </Card>

              <Card className="p-6 border-[#e5e7eb] rounded-xl">
                <h3 className="text-[#111] mb-4">Marketplace Stats</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[#666]">Active Listings</span>
                    <span className="text-[#111]">43</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#666]">Completed Sales</span>
                    <span className="text-[#111]">128</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#666]">Avg. Sale Price</span>
                    <span className="text-[#111]">$67</span>
                  </div>
                </div>
              </Card>

              <Card className="p-6 border-[#e5e7eb] rounded-xl">
                <h3 className="text-[#111] mb-4">Content Moderation</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[#666]">Reports Resolved</span>
                    <span className="text-[#111]">47</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#666]">Avg. Response Time</span>
                    <span className="text-[#111]">2.3 hours</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#666]">Content Removed</span>
                    <span className="text-[#111]">5</span>
                  </div>
                </div>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
