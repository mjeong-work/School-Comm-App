import { useState } from 'react';
import { NavigationBar } from './components/NavigationBar';
import { MarketplaceCard } from './components/MarketplaceCard';
import { FloatingActionButton } from './components/FloatingActionButton';
import { Input } from './components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { Search } from 'lucide-react';

const mockItems = [
  {
    id: '1',
    title: 'Calculus Textbook - 8th Edition',
    category: 'Textbooks',
    price: 45,
    condition: 'Like New',
    description: 'Barely used calculus textbook for MATH 201. Only used for one semester. No highlights or writing inside. Original price was $120.',
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=800&q=80',
    seller: {
      name: 'Anonymous Student',
      contact: 'DM me on Campus Connect',
      verified: true
    },
    postedDate: '2025-10-30',
    views: 156
  },
  {
    id: '2',
    title: 'Mini Fridge - Perfect for Dorm',
    category: 'Appliances',
    price: 80,
    condition: 'Good',
    description: 'Compact mini fridge, great condition. Used for one year in my dorm. 1.7 cubic feet, works perfectly. Can hold drinks and snacks. Pick up only from North Campus.',
    image: 'https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?w=800&q=80',
    seller: {
      name: 'Anonymous Student',
      contact: 'Email: student@campus.edu',
      verified: true
    },
    postedDate: '2025-10-29',
    views: 234
  },
  {
    id: '3',
    title: 'MacBook Pro 13" 2020',
    category: 'Electronics',
    price: 650,
    condition: 'Good',
    description: 'MacBook Pro 13-inch from 2020. 8GB RAM, 256GB SSD. Battery health at 85%. Includes original charger and case. Minor cosmetic wear on the bottom. Fully functional.',
    image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800&q=80',
    seller: {
      name: 'Anonymous Student',
      contact: 'Text: (555) 123-4567',
      verified: true
    },
    postedDate: '2025-10-28',
    views: 445
  },
  {
    id: '4',
    title: 'Desk Lamp with USB Charging Port',
    category: 'Furniture',
    price: 15,
    condition: 'Like New',
    description: 'LED desk lamp with adjustable brightness and built-in USB charging port. Perfect for late-night study sessions. Used for just a few months.',
    image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800&q=80',
    seller: {
      name: 'Anonymous Student',
      contact: 'DM me on Campus Connect',
      verified: true
    },
    postedDate: '2025-10-27',
    views: 89
  },
  {
    id: '5',
    title: 'Guitar - Acoustic Yamaha',
    category: 'Musical Instruments',
    price: 120,
    condition: 'Good',
    description: 'Yamaha acoustic guitar in good condition. Comes with a soft case, extra strings, and a tuner. Great for beginners or intermediate players. Moving and need to sell quickly.',
    image: 'https://images.unsplash.com/photo-1510915361894-db8b60106cb1?w=800&q=80',
    seller: {
      name: 'Anonymous Student',
      contact: 'Email: music.student@campus.edu',
      verified: true
    },
    postedDate: '2025-10-26',
    views: 178
  },
  {
    id: '6',
    title: 'Scientific Calculator TI-84 Plus',
    category: 'School Supplies',
    price: 60,
    condition: 'Like New',
    description: 'TI-84 Plus graphing calculator. Required for most math and science courses. Excellent condition, barely used. Comes with protective cover.',
    image: 'https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=800&q=80',
    seller: {
      name: 'Anonymous Student',
      contact: 'DM me on Campus Connect',
      verified: true
    },
    postedDate: '2025-10-25',
    views: 201
  },
  {
    id: '7',
    title: 'Bicycle - Mountain Bike',
    category: 'Sports & Outdoors',
    price: 200,
    condition: 'Good',
    description: '21-speed mountain bike, great for getting around campus. Has some wear but rides smoothly. Includes lock and water bottle holder. Recent tune-up.',
    image: 'https://images.unsplash.com/photo-1576435728678-68d0fbf94e91?w=800&q=80',
    seller: {
      name: 'Anonymous Student',
      contact: 'Text: (555) 987-6543',
      verified: true
    },
    postedDate: '2025-10-24',
    views: 312
  }
];

export default function MarketplacePage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [category, setCategory] = useState('all');
  const [sortBy, setSortBy] = useState('latest');

  return (
    <div className="min-h-screen bg-white">
      <NavigationBar activeTab="marketplace" />
      
      {/* Main Content */}
      <main className="max-w-[1200px] mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-[#111] mb-1">CAMPUS MARKETPLACE</h1>
          <p className="text-[#666]">Buy and sell second-hand items within the campus community</p>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#666]" />
            <Input
              type="text"
              placeholder="Search items..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 border-[#e5e7eb] rounded-lg h-11 py-2"
            />
          </div>
          
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="w-full sm:w-[200px] border-[#e5e7eb] rounded-lg h-11 py-2">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="textbooks">Textbooks</SelectItem>
              <SelectItem value="electronics">Electronics</SelectItem>
              <SelectItem value="furniture">Furniture</SelectItem>
              <SelectItem value="appliances">Appliances</SelectItem>
              <SelectItem value="sports">Sports & Outdoors</SelectItem>
              <SelectItem value="supplies">School Supplies</SelectItem>
              <SelectItem value="instruments">Musical Instruments</SelectItem>
            </SelectContent>
          </Select>

          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-full sm:w-[200px] border-[#e5e7eb] rounded-lg h-11 py-2">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="latest">Sort by: Latest</SelectItem>
              <SelectItem value="price-low">Price: Low to High</SelectItem>
              <SelectItem value="price-high">Price: High to Low</SelectItem>
              <SelectItem value="popular">Most Viewed</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Items List */}
        <div className="space-y-4">
          {mockItems.map((item) => (
            <MarketplaceCard key={item.id} item={item} />
          ))}
        </div>
      </main>

      {/* Mobile Floating Action Button */}
      <FloatingActionButton />
    </div>
  );
}
