import { Menu } from 'lucide-react';
import { Button } from './ui/button';
import { Sheet, SheetContent, SheetTrigger } from './ui/sheet';

interface NavigationBarProps {
  activeTab?: 'community' | 'events' | 'marketplace' | 'admin' | 'profile';
}

export function NavigationBar({ activeTab = 'community' }: NavigationBarProps) {
  const navLinks = [
    { name: 'Community', href: '#community', active: activeTab === 'community' },
    { name: 'Events', href: '#events', active: activeTab === 'events' },
    { name: 'Marketplace', href: '#marketplace', active: activeTab === 'marketplace' },
    { name: 'Admin', href: '#admin', active: activeTab === 'admin' },
    { name: 'Profile', href: '#profile', active: activeTab === 'profile' }
  ];

  return (
    <nav className="border-b border-[#e5e7eb] bg-white sticky top-0 z-50">
      <div className="max-w-[960px] mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-8">
            <h2 className="text-[#111]">Campus Connect</h2>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    link.active
                      ? 'text-[#0b5fff]'
                      : 'text-[#666] hover:text-[#111] hover:bg-[#f5f5f5]'
                  }`}
                >
                  {link.name}
                </a>
              ))}
            </div>
          </div>

          {/* Mobile Menu */}
          <Sheet>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon" className="text-[#666]">
                <Menu className="w-6 h-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[280px]">
              <div className="flex flex-col gap-2 mt-8">
                {navLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    className={`px-4 py-3 rounded-lg transition-colors ${
                      link.active
                        ? 'text-[#0b5fff] bg-[#eff6ff]'
                        : 'text-[#666] hover:text-[#111] hover:bg-[#f5f5f5]'
                    }`}
                  >
                    {link.name}
                  </a>
                ))}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
