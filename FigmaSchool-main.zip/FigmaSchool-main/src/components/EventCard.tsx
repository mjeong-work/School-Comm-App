import { useState } from 'react';
import { Heart, MessageCircle, MapPin, Calendar, Clock, Users, CheckCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  venue: string;
  participants: number;
  userRSVP: boolean;
  description: string;
  image: string;
  likes: number;
  comments: number;
}

interface EventCardProps {
  event: Event;
}

export function EventCard({ event }: EventCardProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(event.likes);
  const [hasRSVPed, setHasRSVPed] = useState(event.userRSVP);
  const [participantsCount, setParticipantsCount] = useState(event.participants);

  const handleLike = () => {
    if (isLiked) {
      setLikesCount(likesCount - 1);
      setIsLiked(false);
    } else {
      setLikesCount(likesCount + 1);
      setIsLiked(true);
    }
  };

  const handleRSVP = () => {
    if (hasRSVPed) {
      setParticipantsCount(participantsCount - 1);
      setHasRSVPed(false);
    } else {
      setParticipantsCount(participantsCount + 1);
      setHasRSVPed(true);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="bg-white border border-[#e5e7eb] rounded-xl overflow-hidden hover:border-[#d1d5db] transition-colors">
      <div className="flex flex-col sm:flex-row">
        {/* Image */}
        <div className="sm:w-[240px] sm:h-[200px] shrink-0">
          <ImageWithFallback
            src={event.image}
            alt={event.title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Content */}
        <div className="flex-1 p-5 sm:p-6">
          {/* Header */}
          <div className="flex items-start justify-between gap-3 mb-3">
            <h3 className="text-[#111] flex-1">{event.title}</h3>
            {hasRSVPed && (
              <Badge className="bg-[#eff6ff] text-[#0b5fff] border-[#0b5fff]/20 hover:bg-[#eff6ff] gap-1 px-2 py-1 shrink-0">
                <CheckCircle className="w-3 h-3" />
                RSVP'd
              </Badge>
            )}
          </div>

          {/* Event Details */}
          <div className="space-y-2 mb-4">
            <div className="flex items-start gap-2 text-[#666]">
              <Calendar className="w-4 h-4 mt-0.5 shrink-0" />
              <div className="flex flex-wrap items-center gap-2 text-sm">
                <span>{formatDate(event.date)}</span>
                <span className="text-[#d1d5db]">•</span>
                <div className="flex items-center gap-1.5">
                  <Clock className="w-4 h-4" />
                  <span>{event.time}</span>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-2 text-[#666]">
              <MapPin className="w-4 h-4 mt-0.5 shrink-0" />
              <span className="text-sm">{event.venue}</span>
            </div>

            <div className="flex items-center gap-2 text-[#666]">
              <Users className="w-4 h-4 shrink-0" />
              <span className="text-sm">{participantsCount} participants</span>
            </div>
          </div>

          {/* Description */}
          <p className="text-[#333] text-sm mb-4 line-clamp-2">{event.description}</p>

          {/* Actions */}
          <div className="flex items-center gap-4 pt-4 border-t border-[#e5e7eb]">
            <Button
              onClick={handleRSVP}
              className={`px-6 py-2 rounded-lg transition-colors ${
                hasRSVPed
                  ? 'bg-[#f5f5f5] text-[#666] hover:bg-[#e5e7eb] border border-[#e5e7eb]'
                  : 'bg-[#0b5fff] hover:bg-[#0949cc] text-white shadow-sm'
              }`}
            >
              {hasRSVPed ? 'Cancel RSVP' : 'RSVP'}
            </Button>

            <button
              onClick={handleLike}
              className="flex items-center gap-2 text-[#666] hover:text-[#0b5fff] transition-colors group"
            >
              <Heart 
                className={`w-5 h-5 transition-all ${
                  isLiked ? 'fill-[#0b5fff] text-[#0b5fff]' : 'group-hover:scale-110'
                }`}
              />
              <span className="text-sm">{likesCount}</span>
            </button>

            <button className="flex items-center gap-2 text-[#666] hover:text-[#0b5fff] transition-colors">
              <MessageCircle className="w-5 h-5" />
              <span className="text-sm">{event.comments}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
