import { useState } from 'react';
import { Heart, Eye, BadgeCheck, MessageCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface MarketplaceItem {
  id: string;
  title: string;
  category: string;
  price: number;
  condition: string;
  description: string;
  image: string;
  seller: {
    name: string;
    contact: string;
    verified: boolean;
  };
  postedDate: string;
  views: number;
}

interface MarketplaceCardProps {
  item: MarketplaceItem;
}

export function MarketplaceCard({ item }: MarketplaceCardProps) {
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    setIsSaved(!isSaved);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getConditionColor = (condition: string) => {
    switch (condition.toLowerCase()) {
      case 'like new':
        return 'bg-[#ecfdf5] text-[#059669] border-[#059669]/20';
      case 'good':
        return 'bg-[#eff6ff] text-[#0b5fff] border-[#0b5fff]/20';
      case 'fair':
        return 'bg-[#fef3c7] text-[#d97706] border-[#d97706]/20';
      default:
        return 'bg-[#f5f5f5] text-[#666] border-[#e5e7eb]';
    }
  };

  return (
    <div className="bg-white border border-[#e5e7eb] rounded-xl overflow-hidden hover:border-[#d1d5db] transition-colors">
      <div className="flex flex-col sm:flex-row">
        {/* Image */}
        <div className="sm:w-[280px] sm:h-[240px] shrink-0">
          <ImageWithFallback
            src={item.image}
            alt={item.title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Content */}
        <div className="flex-1 p-5 sm:p-6">
          {/* Header */}
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <Badge className="bg-[#f5f5f5] text-[#666] border-[#e5e7eb] hover:bg-[#f5f5f5] text-xs px-2 py-0.5">
                  {item.category}
                </Badge>
                <Badge className={`${getConditionColor(item.condition)} hover:${getConditionColor(item.condition)} text-xs px-2 py-0.5`}>
                  {item.condition}
                </Badge>
              </div>
              <h3 className="text-[#111] mb-1">{item.title}</h3>
              <div className="text-[#0b5fff]">
                ${item.price}
              </div>
            </div>
            
            <button
              onClick={handleSave}
              className="text-[#666] hover:text-[#0b5fff] transition-colors shrink-0"
            >
              <Heart 
                className={`w-6 h-6 transition-all ${
                  isSaved ? 'fill-[#0b5fff] text-[#0b5fff]' : ''
                }`}
              />
            </button>
          </div>

          {/* Description */}
          <p className="text-[#333] text-sm mb-4 line-clamp-2">{item.description}</p>

          {/* Seller Info */}
          <div className="bg-[#f9fafb] rounded-lg p-3 mb-4 border border-[#e5e7eb]">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1">
                <div className="flex items-center gap-1.5 mb-1">
                  <span className="text-sm text-[#666]">Seller:</span>
                  <span className="text-sm text-[#111]">{item.seller.name}</span>
                  {item.seller.verified && (
                    <BadgeCheck className="w-4 h-4 text-[#0b5fff]" />
                  )}
                </div>
                <div className="flex items-center gap-1.5">
                  <MessageCircle className="w-4 h-4 text-[#666]" />
                  <span className="text-sm text-[#666]">{item.seller.contact}</span>
                </div>
              </div>
              
              <Button className="bg-[#0b5fff] hover:bg-[#0949cc] text-white px-4 py-2 rounded-lg shadow-sm text-sm">
                Contact Seller
              </Button>
            </div>
          </div>

          {/* Footer */}
          <div className="flex items-center gap-4 text-sm text-[#666]">
            <div className="flex items-center gap-1.5">
              <Eye className="w-4 h-4" />
              <span>{item.views} views</span>
            </div>
            <span className="text-[#d1d5db]">•</span>
            <span>Posted {formatDate(item.postedDate)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
