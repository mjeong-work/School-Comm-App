import { useState } from 'react';
import { NavigationBar } from './components/NavigationBar';
import { Card } from './components/ui/card';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';
import { Textarea } from './components/ui/textarea';
import { Checkbox } from './components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { Separator } from './components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from './components/ui/avatar';
import { ArrowLeft, Upload } from 'lucide-react';

export default function EditProfilePage() {
  const [formData, setFormData] = useState({
    name: 'Alex Chen',
    email: 'alex.chen@campus.edu',
    bio: 'CS student passionate about AI and machine learning. Love connecting with fellow students and sharing resources!',
    major: 'Computer Science',
    graduationYear: '2026',
    location: 'North Campus',
    townCommunity: 'Downtown Area',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&q=80'
  });

  const [interests, setInterests] = useState({
    school: true,
    academics: true,
    sports: false,
    arts: true,
    technology: true,
    music: false,
    volunteering: false,
    career: true,
    socialEvents: true,
    foodDining: true,
    fitness: false,
    gaming: true
  });

  const [communities, setCommunities] = useState({
    currentStudents: true,
    alumni: false,
    gradStudents: false,
    international: false,
    localResidents: true,
    campusOrganizations: true
  });

  const handleInterestToggle = (key: string) => {
    setInterests(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleCommunityToggle = (key: string) => {
    setCommunities(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    // In a real app, this would save to backend
    window.location.hash = 'profile';
  };

  const handleCancel = () => {
    window.location.hash = 'profile';
  };

  return (
    <div className="min-h-screen bg-white">
      <NavigationBar activeTab="profile" />
      
      {/* Main Content */}
      <main className="max-w-[960px] mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Header */}
        <div className="mb-6">
          <button 
            onClick={handleCancel}
            className="flex items-center gap-2 text-[#666] hover:text-[#111] mb-4 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Profile</span>
          </button>
          <h1 className="text-[#111] mb-1">EDIT PROFILE</h1>
          <p className="text-[#666]">Update your information and customize your interests</p>
        </div>

        <div className="space-y-6">
          {/* Basic Information */}
          <Card className="p-6 border-[#e5e7eb] rounded-xl">
            <h2 className="text-[#111] mb-4">Basic Information</h2>
            
            {/* Avatar Upload */}
            <div className="mb-6">
              <Label className="text-[#666] mb-2 block">Profile Photo</Label>
              <div className="flex items-center gap-4">
                <Avatar className="w-20 h-20 border-2 border-white shadow-sm">
                  <AvatarImage src={formData.avatar} alt={formData.name} />
                  <AvatarFallback className="text-xl bg-[#0b5fff] text-white">
                    {formData.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <Button className="bg-white border border-[#e5e7eb] text-[#111] hover:bg-[#f9fafb] px-4 py-2 rounded-lg gap-2">
                  <Upload className="w-4 h-4" />
                  Upload Photo
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
              <div>
                <Label htmlFor="name" className="text-[#666] mb-2 block">Full Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  className="border-[#e5e7eb] rounded-lg"
                />
              </div>
              
              <div>
                <Label htmlFor="email" className="text-[#666] mb-2 block">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  disabled
                  className="border-[#e5e7eb] rounded-lg bg-[#f9fafb] text-[#666]"
                />
              </div>
            </div>

            <div className="mb-4">
              <Label htmlFor="bio" className="text-[#666] mb-2 block">Bio</Label>
              <Textarea
                id="bio"
                value={formData.bio}
                onChange={(e) => handleInputChange('bio', e.target.value)}
                className="border-[#e5e7eb] rounded-lg min-h-[100px]"
                placeholder="Tell us about yourself..."
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="major" className="text-[#666] mb-2 block">Major</Label>
                <Input
                  id="major"
                  value={formData.major}
                  onChange={(e) => handleInputChange('major', e.target.value)}
                  className="border-[#e5e7eb] rounded-lg"
                />
              </div>
              
              <div>
                <Label htmlFor="graduationYear" className="text-[#666] mb-2 block">Graduation Year</Label>
                <Select value={formData.graduationYear} onValueChange={(value) => handleInputChange('graduationYear', value)}>
                  <SelectTrigger className="border-[#e5e7eb] rounded-lg">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2025">2025</SelectItem>
                    <SelectItem value="2026">2026</SelectItem>
                    <SelectItem value="2027">2027</SelectItem>
                    <SelectItem value="2028">2028</SelectItem>
                    <SelectItem value="2029">2029</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </Card>

          {/* Location Settings */}
          <Card className="p-6 border-[#e5e7eb] rounded-xl">
            <h2 className="text-[#111] mb-4">Location Settings</h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="location" className="text-[#666] mb-2 block">Campus Location</Label>
                <Select value={formData.location} onValueChange={(value) => handleInputChange('location', value)}>
                  <SelectTrigger className="border-[#e5e7eb] rounded-lg">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="North Campus">North Campus</SelectItem>
                    <SelectItem value="South Campus">South Campus</SelectItem>
                    <SelectItem value="East Campus">East Campus</SelectItem>
                    <SelectItem value="West Campus">West Campus</SelectItem>
                    <SelectItem value="Off Campus">Off Campus</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="townCommunity" className="text-[#666] mb-2 block">Town / Community</Label>
                <Select value={formData.townCommunity} onValueChange={(value) => handleInputChange('townCommunity', value)}>
                  <SelectTrigger className="border-[#e5e7eb] rounded-lg">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Downtown Area">Downtown Area</SelectItem>
                    <SelectItem value="University District">University District</SelectItem>
                    <SelectItem value="Suburban Area">Suburban Area</SelectItem>
                    <SelectItem value="City Center">City Center</SelectItem>
                    <SelectItem value="Historic District">Historic District</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </Card>

          {/* Community Preferences */}
          <Card className="p-6 border-[#e5e7eb] rounded-xl">
            <h2 className="text-[#111] mb-2">Community Preferences</h2>
            <p className="text-sm text-[#666] mb-4">Select the communities you want to engage with</p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-start gap-3">
                <Checkbox 
                  id="currentStudents"
                  checked={communities.currentStudents}
                  onCheckedChange={() => handleCommunityToggle('currentStudents')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="currentStudents" className="text-[#111] cursor-pointer">Current Students</Label>
                  <p className="text-xs text-[#666]">Connect with fellow students</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox 
                  id="alumni"
                  checked={communities.alumni}
                  onCheckedChange={() => handleCommunityToggle('alumni')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="alumni" className="text-[#111] cursor-pointer">Alumni Network</Label>
                  <p className="text-xs text-[#666]">Stay connected with graduates</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox 
                  id="gradStudents"
                  checked={communities.gradStudents}
                  onCheckedChange={() => handleCommunityToggle('gradStudents')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="gradStudents" className="text-[#111] cursor-pointer">Graduate Students</Label>
                  <p className="text-xs text-[#666]">Graduate-level connections</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox 
                  id="international"
                  checked={communities.international}
                  onCheckedChange={() => handleCommunityToggle('international')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="international" className="text-[#111] cursor-pointer">International Students</Label>
                  <p className="text-xs text-[#666]">Global campus community</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox 
                  id="localResidents"
                  checked={communities.localResidents}
                  onCheckedChange={() => handleCommunityToggle('localResidents')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="localResidents" className="text-[#111] cursor-pointer">Local Residents</Label>
                  <p className="text-xs text-[#666]">Engage with local community</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox 
                  id="campusOrganizations"
                  checked={communities.campusOrganizations}
                  onCheckedChange={() => handleCommunityToggle('campusOrganizations')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="campusOrganizations" className="text-[#111] cursor-pointer">Campus Organizations</Label>
                  <p className="text-xs text-[#666]">Join student groups and clubs</p>
                </div>
              </div>
            </div>
          </Card>

          {/* Interest Preferences */}
          <Card className="p-6 border-[#e5e7eb] rounded-xl">
            <h2 className="text-[#111] mb-2">Interest Preferences</h2>
            <p className="text-sm text-[#666] mb-4">Customize your feed by selecting topics you're interested in</p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="flex items-start gap-3">
                <Checkbox 
                  id="school"
                  checked={interests.school}
                  onCheckedChange={() => handleInterestToggle('school')}
                  className="mt-1"
                  disabled
                />
                <div>
                  <Label htmlFor="school" className="text-[#111] cursor-pointer">School & Campus</Label>
                  <p className="text-xs text-[#666]">Required</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox 
                  id="academics"
                  checked={interests.academics}
                  onCheckedChange={() => handleInterestToggle('academics')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="academics" className="text-[#111] cursor-pointer">Academics</Label>
                  <p className="text-xs text-[#666]">Study groups, resources</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox 
                  id="sports"
                  checked={interests.sports}
                  onCheckedChange={() => handleInterestToggle('sports')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="sports" className="text-[#111] cursor-pointer">Sports & Recreation</Label>
                  <p className="text-xs text-[#666]">Campus athletics, teams</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox 
                  id="arts"
                  checked={interests.arts}
                  onCheckedChange={() => handleInterestToggle('arts')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="arts" className="text-[#111] cursor-pointer">Arts & Culture</Label>
                  <p className="text-xs text-[#666]">Theater, galleries, exhibits</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox 
                  id="technology"
                  checked={interests.technology}
                  onCheckedChange={() => handleInterestToggle('technology')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="technology" className="text-[#111] cursor-pointer">Technology</Label>
                  <p className="text-xs text-[#666]">Tech talks, hackathons</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox 
                  id="music"
                  checked={interests.music}
                  onCheckedChange={() => handleInterestToggle('music')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="music" className="text-[#111] cursor-pointer">Music</Label>
                  <p className="text-xs text-[#666]">Concerts, performances</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox 
                  id="volunteering"
                  checked={interests.volunteering}
                  onCheckedChange={() => handleInterestToggle('volunteering')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="volunteering" className="text-[#111] cursor-pointer">Volunteering</Label>
                  <p className="text-xs text-[#666]">Community service</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox 
                  id="career"
                  checked={interests.career}
                  onCheckedChange={() => handleInterestToggle('career')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="career" className="text-[#111] cursor-pointer">Career & Networking</Label>
                  <p className="text-xs text-[#666]">Job fairs, mentorship</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox 
                  id="socialEvents"
                  checked={interests.socialEvents}
                  onCheckedChange={() => handleInterestToggle('socialEvents')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="socialEvents" className="text-[#111] cursor-pointer">Social Events</Label>
                  <p className="text-xs text-[#666]">Parties, meetups</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox 
                  id="foodDining"
                  checked={interests.foodDining}
                  onCheckedChange={() => handleInterestToggle('foodDining')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="foodDining" className="text-[#111] cursor-pointer">Food & Dining</Label>
                  <p className="text-xs text-[#666]">Restaurants, food events</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox 
                  id="fitness"
                  checked={interests.fitness}
                  onCheckedChange={() => handleInterestToggle('fitness')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="fitness" className="text-[#111] cursor-pointer">Fitness & Wellness</Label>
                  <p className="text-xs text-[#666]">Gym, yoga, health</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox 
                  id="gaming"
                  checked={interests.gaming}
                  onCheckedChange={() => handleInterestToggle('gaming')}
                  className="mt-1"
                />
                <div>
                  <Label htmlFor="gaming" className="text-[#111] cursor-pointer">Gaming</Label>
                  <p className="text-xs text-[#666]">Esports, game nights</p>
                </div>
              </div>
            </div>
          </Card>

          {/* Action Buttons */}
          <div className="flex flex-col-reverse sm:flex-row gap-3 sm:justify-end">
            <Button 
              onClick={handleCancel}
              className="bg-white border border-[#e5e7eb] text-[#111] hover:bg-[#f9fafb] px-6 py-2 rounded-lg"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSave}
              className="bg-[#0b5fff] hover:bg-[#0949cc] text-white px-6 py-2 rounded-lg shadow-sm"
            >
              Save Changes
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
