import { useState, useEffect } from 'react';
import CommunityPage from './CommunityPage';
import EventsPage from './EventsPage';
import MarketplacePage from './MarketplacePage';
import ProfilePage from './ProfilePage';
import AdminPage from './AdminPage';
import EditProfilePage from './EditProfilePage';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'community' | 'events' | 'marketplace' | 'profile' | 'admin' | 'edit-profile'>('community');

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.slice(1);
      if (hash === 'events') {
        setCurrentPage('events');
      } else if (hash === 'marketplace') {
        setCurrentPage('marketplace');
      } else if (hash === 'profile') {
        setCurrentPage('profile');
      } else if (hash === 'admin') {
        setCurrentPage('admin');
      } else if (hash === 'edit-profile') {
        setCurrentPage('edit-profile');
      } else {
        setCurrentPage('community');
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange(); // Check initial hash

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  return (
    <>
      {currentPage === 'community' && <CommunityPage />}
      {currentPage === 'events' && <EventsPage />}
      {currentPage === 'marketplace' && <MarketplacePage />}
      {currentPage === 'profile' && <ProfilePage />}
      {currentPage === 'admin' && <AdminPage />}
      {currentPage === 'edit-profile' && <EditProfilePage />}
    </>
  );
}
