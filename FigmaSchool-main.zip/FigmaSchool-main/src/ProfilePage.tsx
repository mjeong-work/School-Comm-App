import { useState } from 'react';
import { NavigationBar } from './components/NavigationBar';
import { Card } from './components/ui/card';
import { Button } from './components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Badge } from './components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './components/ui/avatar';
import { 
  Mail, 
  MapPin, 
  Calendar, 
  BadgeCheck, 
  Settings,
  MessageSquare,
  CalendarDays,
  ShoppingBag,
  Heart,
  Eye
} from 'lucide-react';

const userProfile = {
  name: 'Alex Chen',
  email: 'alex.chen@campus.edu',
  avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&q=80',
  verified: true,
  major: 'Computer Science',
  graduationYear: '2026',
  location: 'North Campus',
  joinDate: '2024-09-01',
  bio: 'CS student passionate about AI and machine learning. Love connecting with fellow students and sharing resources!',
  stats: {
    posts: 23,
    eventsAttended: 12,
    itemsSold: 8,
    savedItems: 15
  }
};

const userActivity = {
  posts: [
    {
      id: '1',
      title: 'Looking for study group partners for CS101',
      date: '2025-10-28',
      likes: 24,
      comments: 5
    },
    {
      id: '2',
      title: 'Free pizza at the Student Center today!',
      date: '2025-10-30',
      likes: 156,
      comments: 12
    },
    {
      id: '3',
      title: 'Best coffee spots on campus?',
      date: '2025-10-27',
      likes: 45,
      comments: 8
    }
  ],
  events: [
    {
      id: '1',
      title: 'Fall Semester Study Break - Free Coffee & Snacks',
      date: '2025-11-01',
      status: 'RSVP\'d'
    },
    {
      id: '2',
      title: 'International Food Festival',
      date: '2025-11-10',
      status: 'RSVP\'d'
    },
    {
      id: '3',
      title: 'CS Department Career Fair',
      date: '2025-11-05',
      status: 'RSVP\'d'
    }
  ],
  items: [
    {
      id: '1',
      title: 'Calculus Textbook - 8th Edition',
      price: 45,
      views: 156,
      status: 'Active'
    },
    {
      id: '2',
      title: 'Scientific Calculator TI-84 Plus',
      price: 60,
      views: 201,
      status: 'Active'
    }
  ]
};

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState('posts');

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'long',
      year: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-white">
      <NavigationBar activeTab="profile" />
      
      {/* Main Content */}
      <main className="max-w-[960px] mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Profile Header Card */}
        <Card className="p-6 sm:p-8 border-[#e5e7eb] rounded-xl mb-6">
          <div className="flex flex-col sm:flex-row gap-6">
            {/* Avatar */}
            <div className="flex justify-center sm:justify-start">
              <Avatar className="w-24 h-24 sm:w-32 sm:h-32 border-4 border-white shadow-lg">
                <AvatarImage src={userProfile.avatar} alt={userProfile.name} />
                <AvatarFallback className="text-2xl bg-[#0b5fff] text-white">
                  {userProfile.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
            </div>

            {/* Profile Info */}
            <div className="flex-1 text-center sm:text-left">
              <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-4">
                <div>
                  <div className="flex items-center justify-center sm:justify-start gap-2 mb-2">
                    <h1 className="text-[#111]">{userProfile.name}</h1>
                    {userProfile.verified && (
                      <BadgeCheck className="w-6 h-6 text-[#0b5fff]" />
                    )}
                  </div>
                  <p className="text-[#666] mb-3">{userProfile.bio}</p>
                </div>
                
                <Button 
                  onClick={() => window.location.hash = 'edit-profile'}
                  className="bg-white border border-[#e5e7eb] text-[#111] hover:bg-[#f9fafb] px-4 py-2 rounded-lg gap-2 self-center sm:self-start"
                >
                  <Settings className="w-4 h-4" />
                  Edit Profile
                </Button>
              </div>

              {/* User Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-4 text-sm">
                <div className="flex items-center justify-center sm:justify-start gap-2 text-[#666]">
                  <Mail className="w-4 h-4" />
                  <span>{userProfile.email}</span>
                </div>
                <div className="flex items-center justify-center sm:justify-start gap-2 text-[#666]">
                  <MapPin className="w-4 h-4" />
                  <span>{userProfile.location}</span>
                </div>
                <div className="flex items-center justify-center sm:justify-start gap-2 text-[#666]">
                  <BadgeCheck className="w-4 h-4" />
                  <span>{userProfile.major} • Class of {userProfile.graduationYear}</span>
                </div>
                <div className="flex items-center justify-center sm:justify-start gap-2 text-[#666]">
                  <Calendar className="w-4 h-4" />
                  <span>Joined {formatDate(userProfile.joinDate)}</span>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-[#e5e7eb]">
                <div className="text-center">
                  <div className="text-[#111] mb-1">{userProfile.stats.posts}</div>
                  <div className="text-sm text-[#666]">Posts</div>
                </div>
                <div className="text-center">
                  <div className="text-[#111] mb-1">{userProfile.stats.eventsAttended}</div>
                  <div className="text-sm text-[#666]">Events</div>
                </div>
                <div className="text-center">
                  <div className="text-[#111] mb-1">{userProfile.stats.itemsSold}</div>
                  <div className="text-sm text-[#666]">Items Sold</div>
                </div>
                <div className="text-center">
                  <div className="text-[#111] mb-1">{userProfile.stats.savedItems}</div>
                  <div className="text-sm text-[#666]">Saved</div>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Activity Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full sm:w-auto bg-white border border-[#e5e7eb] p-1 mb-6">
            <TabsTrigger 
              value="posts" 
              className="data-[state=active]:bg-[#0b5fff] data-[state=active]:text-white px-4 py-2 rounded-lg gap-2"
            >
              <MessageSquare className="w-4 h-4" />
              My Posts
            </TabsTrigger>
            <TabsTrigger 
              value="events" 
              className="data-[state=active]:bg-[#0b5fff] data-[state=active]:text-white px-4 py-2 rounded-lg gap-2"
            >
              <CalendarDays className="w-4 h-4" />
              My Events
            </TabsTrigger>
            <TabsTrigger 
              value="items" 
              className="data-[state=active]:bg-[#0b5fff] data-[state=active]:text-white px-4 py-2 rounded-lg gap-2"
            >
              <ShoppingBag className="w-4 h-4" />
              My Items
            </TabsTrigger>
          </TabsList>

          {/* My Posts */}
          <TabsContent value="posts" className="space-y-3">
            {userActivity.posts.map((post) => (
              <Card key={post.id} className="p-4 sm:p-5 border-[#e5e7eb] rounded-xl hover:border-[#d1d5db] transition-colors">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <h3 className="text-[#111] mb-2">{post.title}</h3>
                    <div className="flex items-center gap-4 text-sm text-[#666]">
                      <span>{new Date(post.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                      <div className="flex items-center gap-1">
                        <Heart className="w-4 h-4" />
                        <span>{post.likes}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MessageSquare className="w-4 h-4" />
                        <span>{post.comments}</span>
                      </div>
                    </div>
                  </div>
                  <Button className="bg-white border border-[#e5e7eb] text-[#111] hover:bg-[#f9fafb] px-3 py-2 rounded-lg text-sm">
                    View
                  </Button>
                </div>
              </Card>
            ))}
          </TabsContent>

          {/* My Events */}
          <TabsContent value="events" className="space-y-3">
            {userActivity.events.map((event) => (
              <Card key={event.id} className="p-4 sm:p-5 border-[#e5e7eb] rounded-xl hover:border-[#d1d5db] transition-colors">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-start gap-2 mb-2">
                      <h3 className="text-[#111] flex-1">{event.title}</h3>
                      <Badge className="bg-[#eff6ff] text-[#0b5fff] border-[#0b5fff]/20 hover:bg-[#eff6ff] text-xs px-2 py-1">
                        {event.status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-[#666]">
                      <Calendar className="w-4 h-4" />
                      <span>{new Date(event.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                    </div>
                  </div>
                  <Button className="bg-white border border-[#e5e7eb] text-[#111] hover:bg-[#f9fafb] px-3 py-2 rounded-lg text-sm">
                    View
                  </Button>
                </div>
              </Card>
            ))}
          </TabsContent>

          {/* My Items */}
          <TabsContent value="items" className="space-y-3">
            {userActivity.items.map((item) => (
              <Card key={item.id} className="p-4 sm:p-5 border-[#e5e7eb] rounded-xl hover:border-[#d1d5db] transition-colors">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-start gap-2 mb-2">
                      <h3 className="text-[#111] flex-1">{item.title}</h3>
                      <div className="text-[#0b5fff]">${item.price}</div>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-[#666]">
                      <Badge className="bg-[#ecfdf5] text-[#059669] border-[#059669]/20 hover:bg-[#ecfdf5] text-xs px-2 py-1">
                        {item.status}
                      </Badge>
                      <div className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        <span>{item.views} views</span>
                      </div>
                    </div>
                  </div>
                  <Button className="bg-white border border-[#e5e7eb] text-[#111] hover:bg-[#f9fafb] px-3 py-2 rounded-lg text-sm">
                    Edit
                  </Button>
                </div>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
