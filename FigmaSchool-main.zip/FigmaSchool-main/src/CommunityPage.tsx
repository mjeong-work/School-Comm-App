import { useState } from 'react';
import { NavigationBar } from './components/NavigationBar';
import { PostCard } from './components/PostCard';
import { FloatingActionButton } from './components/FloatingActionButton';
import { CreatePostDialog } from './components/CreatePostDialog';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Tabs, TabsList, TabsTrigger } from './components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { Search, Plus } from 'lucide-react';

const mockPosts = [
  {
    id: '1',
    title: 'Looking for study group partners for CS101',
    date: '2025-10-28',
    author: 'Anonymous Student',
    verified: true,
    content: 'Hey everyone! I\'m looking for a few people to form a study group for CS101. We can meet in the library twice a week. Anyone interested?',
    image: null,
    likes: 24,
    comments: [
      { id: '1', author: 'Anonymous', text: 'I\'d be interested! What times work for you?', date: '2025-10-28' },
      { id: '2', author: 'Anonymous', text: 'Count me in! Tuesday and Thursday evenings would be great.', date: '2025-10-29' }
    ]
  },
  {
    id: '2',
    title: 'Free pizza at the Student Center today!',
    date: '2025-10-30',
    author: 'Anonymous Student',
    verified: true,
    content: 'The Computer Science club is giving away free pizza slices from 12-2pm at the Student Center. First come, first served!',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=800&q=80',
    likes: 156,
    comments: [
      { id: '1', author: 'Anonymous', text: 'OMG thank you for sharing! 🍕', date: '2025-10-30' },
      { id: '2', author: 'Anonymous', text: 'Are there veggie options?', date: '2025-10-30' },
      { id: '3', author: 'Anonymous', text: 'Yes! Cheese and veggie supreme available', date: '2025-10-30' }
    ]
  },
  {
    id: '3',
    title: 'Lost: Blue backpack near Engineering building',
    date: '2025-10-29',
    author: 'Anonymous Student',
    verified: true,
    content: 'I lost my blue JanSport backpack yesterday near the Engineering building. It has my laptop and textbooks. If anyone finds it, please contact the campus lost & found.',
    image: null,
    likes: 12,
    comments: [
      { id: '1', author: 'Anonymous', text: 'I saw someone turn in a blue backpack at the library desk this morning!', date: '2025-10-29' }
    ]
  },
  {
    id: '4',
    title: 'Best coffee spots on campus?',
    date: '2025-10-27',
    author: 'Anonymous Student',
    verified: true,
    content: 'New transfer student here! What are the best places to grab coffee between classes? Looking for somewhere with good wifi and not too crowded.',
    image: null,
    likes: 45,
    comments: [
      { id: '1', author: 'Anonymous', text: 'The café in the Arts building is pretty quiet and has great cold brew!', date: '2025-10-27' },
      { id: '2', author: 'Anonymous', text: 'Commons Café is my favorite - good prices too', date: '2025-10-28' }
    ]
  },
  {
    id: '5',
    title: 'Campus cleanup volunteer opportunity',
    date: '2025-10-26',
    author: 'Anonymous Student',
    verified: true,
    content: 'Join us this Saturday for a campus cleanup event! We\'ll be beautifying the quad and planting some new trees. Free t-shirt and lunch for all volunteers. Sign up link in comments.',
    image: 'https://images.unsplash.com/photo-1559027615-cd4628902d4a?w=800&q=80',
    likes: 89,
    comments: [
      { id: '1', author: 'Anonymous', text: 'What time does it start?', date: '2025-10-26' },
      { id: '2', author: 'Anonymous', text: '9am - 2pm, but you can join anytime!', date: '2025-10-26' }
    ]
  }
];

export default function CommunityPage() {
  const [selectedTab, setSelectedTab] = useState('current-students');
  const [sortBy, setSortBy] = useState('latest');
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);
  const [posts, setPosts] = useState(mockPosts);

  const handleCreatePost = (newPost: {
    title: string;
    category: string;
    content: string;
    image?: string;
    date: string;
  }) => {
    const post = {
      id: String(Date.now()),
      title: newPost.title,
      date: newPost.date,
      author: 'Anonymous Student',
      verified: true,
      content: newPost.content,
      image: newPost.image || null,
      likes: 0,
      comments: []
    };

    setPosts([post, ...posts]);
  };

  return (
    <div className="min-h-screen bg-white">
      <NavigationBar activeTab="community" />
      
      {/* Main Content */}
      <main className="max-w-[960px] mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-[#111] mb-1">COMMUNITY BOARDS</h1>
          <p className="text-[#666]">Verified members only.</p>
        </div>

        {/* Tabs and Post Button */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full sm:w-auto">
            <TabsList className="w-full sm:w-auto overflow-x-auto bg-white border border-[#e5e7eb] p-1 h-auto">
              <TabsTrigger 
                value="current-students" 
                className="data-[state=active]:bg-[#0b5fff] data-[state=active]:text-white whitespace-nowrap px-4 py-2 rounded-lg"
              >
                Current Students
              </TabsTrigger>
              <TabsTrigger 
                value="alumni" 
                className="data-[state=active]:bg-[#0b5fff] data-[state=active]:text-white whitespace-nowrap px-4 py-2 rounded-lg"
              >
                Alumni
              </TabsTrigger>
              <TabsTrigger 
                value="all-school" 
                className="data-[state=active]:bg-[#0b5fff] data-[state=active]:text-white whitespace-nowrap px-4 py-2 rounded-lg"
              >
                All School
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {/* Desktop Post Button */}
          <Button 
            onClick={() => setIsCreatePostOpen(true)}
            className="hidden sm:flex bg-[#0b5fff] hover:bg-[#0949cc] text-white px-6 py-2 rounded-lg gap-2 shadow-sm"
          >
            <Plus className="w-5 h-5" />
            Post
          </Button>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#666]" />
            <Input
              type="text"
              placeholder="Search posts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 border-[#e5e7eb] rounded-lg h-11 py-2"
            />
          </div>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-full sm:w-[200px] border-[#e5e7eb] rounded-lg h-11 py-2">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="latest">Sort by: Latest</SelectItem>
              <SelectItem value="most-liked">Sort by: Most liked</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Posts Feed */}
        <div className="space-y-4">
          {posts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      </main>

      {/* Create Post Dialog */}
      <CreatePostDialog 
        open={isCreatePostOpen}
        onOpenChange={setIsCreatePostOpen}
        onSubmit={handleCreatePost}
      />

      {/* Mobile Floating Action Button */}
      <FloatingActionButton onClick={() => setIsCreatePostOpen(true)} />
    </div>
  );
}
