
  # Design Community Feed Page

  This is a code bundle for Design Community Feed Page. The original project is available at https://www.figma.com/design/3CsH3mXweIbZLR9iQzJ8rU/Design-Community-Feed-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  